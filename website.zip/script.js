function moveGallery(direction){const slider=document.getElementById('gallerySlider');if(!slider)return;const amount=Math.min(360,slider.clientWidth*0.75);slider.scrollBy({left:direction*amount,behavior:'smooth'});}
const BOOKING_ICS_URL = "https://ical.booking.com/v1/export?t=f417174c-656a-4f9d-b8eb-b26d0589cefd";
let currentDate = new Date();
let bookingBusyRanges = [];

function parseIcsDate(value){
  if(!value) return null;
  const s = String(value).trim().slice(0,8);
  const y = Number(s.slice(0,4));
  const m = Number(s.slice(4,6)) - 1;
  const d = Number(s.slice(6,8));
  if(!y || Number.isNaN(m) || !d) return null;
  return new Date(y,m,d);
}

function unfoldIcs(text){
  return String(text || '').replace(/\r?\n[ \t]/g,'');
}

function parseBookingIcs(text){
  const clean = unfoldIcs(text);
  const events = clean.split('BEGIN:VEVENT').slice(1);
  const ranges = [];
  for(const ev of events){
    const startMatch = ev.match(/DTSTART(?:;[^:\r\n]*)?:(\d{8})/);
    const endMatch = ev.match(/DTEND(?:;[^:\r\n]*)?:(\d{8})/);
    if(!startMatch || !endMatch) continue;
    const start = parseIcsDate(startMatch[1]);
    const end = parseIcsDate(endMatch[1]);
    if(start && end) ranges.push({start,end});
  }
  return ranges;
}

function isBookingBusy(date){
  const day = new Date(date.getFullYear(),date.getMonth(),date.getDate()).getTime();
  return bookingBusyRanges.some(r=>{
    const s = new Date(r.start.getFullYear(),r.start.getMonth(),r.start.getDate()).getTime();
    const e = new Date(r.end.getFullYear(),r.end.getMonth(),r.end.getDate()).getTime();
    return day >= s && day < e;
  });
}

function renderCalendar(){
  const title=document.getElementById('calendarTitle');
  const days=document.getElementById('calendarDays');
  if(!title||!days)return;
  const year=currentDate.getFullYear();
  const month=currentDate.getMonth();
  const names=['Siječanj','Veljača','Ožujak','Travanj','Svibanj','Lipanj','Srpanj','Kolovoz','Rujan','Listopad','Studeni','Prosinac'];
  title.textContent=names[month]+' '+year;
  days.innerHTML='';
  const first=new Date(year,month,1);
  const last=new Date(year,month+1,0);
  let start=first.getDay();
  start=start===0?6:start-1;
  for(let i=0;i<start;i++){
    const e=document.createElement('span');
    e.className='muted';
    days.appendChild(e);
  }
  const today=new Date();
  for(let d=1;d<=last.getDate();d++){
    const date = new Date(year,month,d);
    const cell=document.createElement('span');
    cell.textContent=d;
    const classes=[];
    if(d===today.getDate()&&month===today.getMonth()&&year===today.getFullYear()) classes.push('today');
    if(isBookingBusy(date)) classes.push('busy');
    if(classes.length) cell.className=classes.join(' ');
    days.appendChild(cell);
  }
}

function changeMonth(delta){
  currentDate=new Date(currentDate.getFullYear(),currentDate.getMonth()+delta,1);
  renderCalendar();
}

async function fetchBookingIcs(){
  const urls = [
    BOOKING_ICS_URL,
    'https://api.allorigins.win/raw?url=' + encodeURIComponent(BOOKING_ICS_URL),
    'https://corsproxy.io/?' + encodeURIComponent(BOOKING_ICS_URL)
  ];
  let lastError = null;
  for(const url of urls){
    try{
      const res = await fetch(url, {cache:'no-store'});
      if(!res.ok) throw new Error('HTTP '+res.status);
      const text = await res.text();
      if(text.includes('BEGIN:VCALENDAR') || text.includes('BEGIN:VEVENT')) return text;
    }catch(e){
      lastError = e;
    }
  }
  throw lastError || new Error('Ne mogu učitati kalendar.');
}

async function loadBookingCalendar(){
  const status = document.getElementById('calendarStatus');
  renderCalendar();
  try{
    if(status) status.textContent='Učitavam kalendar...';
    const ics = await fetchBookingIcs();
    bookingBusyRanges = parseBookingIcs(ics);
    renderCalendar();
    if(status){
      status.textContent = bookingBusyRanges.length
        ? 'Crveno označeni datumi su zauzeti.'
        : 'Kalendar je učitan, ali kalendar trenutno nema zauzete termine.';
    }
  }catch(e){
    console.error(e);
    if(status) status.textContent='Kalendar se trenutno ne može automatski učitati. Pošalji WhatsApp upit za provjeru termina.';
  }
}

document.addEventListener('DOMContentLoaded',loadBookingCalendar);
