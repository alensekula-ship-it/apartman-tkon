function moveGallery(direction){const slider=document.getElementById('gallerySlider');if(!slider)return;const amount=Math.min(360,slider.clientWidth*0.75);slider.scrollBy({left:direction*amount,behavior:'smooth'});}
let currentDate=new Date();
function renderCalendar(){const title=document.getElementById('calendarTitle');const days=document.getElementById('calendarDays');if(!title||!days)return;const year=currentDate.getFullYear();const month=currentDate.getMonth();const names=['Siječanj','Veljača','Ožujak','Travanj','Svibanj','Lipanj','Srpanj','Kolovoz','Rujan','Listopad','Studeni','Prosinac'];title.textContent=names[month]+' '+year;days.innerHTML='';const first=new Date(year,month,1);const last=new Date(year,month+1,0);let start=first.getDay();start=start===0?6:start-1;for(let i=0;i<start;i++){const e=document.createElement('span');e.className='muted';days.appendChild(e);}const today=new Date();for(let d=1;d<=last.getDate();d++){const cell=document.createElement('span');cell.textContent=d;if(d===today.getDate()&&month===today.getMonth()&&year===today.getFullYear()){cell.className='today';}days.appendChild(cell);}}
function changeMonth(delta){currentDate=new Date(currentDate.getFullYear(),currentDate.getMonth()+delta,1);renderCalendar();}
document.addEventListener('DOMContentLoaded',renderCalendar);


/* Booking iCal direct availability - TKON */
const BOOKING_ICS_URL = (document.getElementById('bookingIcsUrl')?.textContent || '').trim();
let icsMonth = new Date();
let busyRanges = [];

function parseIcsDate(value) {
  if (!value) return null;
  value = value.trim();
  const datePart = value.substring(0, 8);
  const y = Number(datePart.substring(0, 4));
  const m = Number(datePart.substring(4, 6)) - 1;
  const d = Number(datePart.substring(6, 8));
  if (!y || Number.isNaN(m) || !d) return null;
  return new Date(y, m, d);
}

function unfoldIcs(text) {
  return text.replace(/\r?\n[ \t]/g, '');
}

function parseBookingIcs(text) {
  const clean = unfoldIcs(text);
  const events = clean.split('BEGIN:VEVENT').slice(1);
  const ranges = [];

  for (const ev of events) {
    const startMatch = ev.match(/DTSTART(?:;[^:\r\n]*)?:(\d{8})/);
    const endMatch = ev.match(/DTEND(?:;[^:\r\n]*)?:(\d{8})/);
    if (!startMatch || !endMatch) continue;

    const start = parseIcsDate(startMatch[1]);
    const endExclusive = parseIcsDate(endMatch[1]);
    if (!start || !endExclusive) continue;

    ranges.push({ start, end: endExclusive });
  }
  return ranges;
}

function isBusyDate(date) {
  const day = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  return busyRanges.some(r => {
    const s = new Date(r.start.getFullYear(), r.start.getMonth(), r.start.getDate()).getTime();
    const e = new Date(r.end.getFullYear(), r.end.getMonth(), r.end.getDate()).getTime();
    return day >= s && day < e;
  });
}

function renderIcsCalendar() {
  const grid = document.getElementById('icsCalendar');
  const title = document.getElementById('icsMonthTitle');
  if (!grid || !title) return;

  const monthNames = ['Siječanj','Veljača','Ožujak','Travanj','Svibanj','Lipanj','Srpanj','Kolovoz','Rujan','Listopad','Studeni','Prosinac'];
  const year = icsMonth.getFullYear();
  const month = icsMonth.getMonth();
  title.textContent = monthNames[month] + ' ' + year;

  grid.innerHTML = '<div class="icsWeek">Pon</div><div class="icsWeek">Uto</div><div class="icsWeek">Sri</div><div class="icsWeek">Čet</div><div class="icsWeek">Pet</div><div class="icsWeek">Sub</div><div class="icsWeek">Ned</div>';

  const first = new Date(year, month, 1);
  const last = new Date(year, month + 1, 0);
  let start = first.getDay();
  start = start === 0 ? 6 : start - 1;

  for (let i = 0; i < start; i++) {
    const cell = document.createElement('div');
    cell.className = 'icsDay muted';
    grid.appendChild(cell);
  }

  const today = new Date();
  for (let d = 1; d <= last.getDate(); d++) {
    const current = new Date(year, month, d);
    const cell = document.createElement('div');
    cell.className = 'icsDay';
    cell.textContent = String(d);

    if (current.toDateString() === today.toDateString()) cell.classList.add('today');
    if (isBusyDate(current)) cell.classList.add('busy');

    grid.appendChild(cell);
  }
}

function prevIcsMonth() {
  icsMonth = new Date(icsMonth.getFullYear(), icsMonth.getMonth() - 1, 1);
  renderIcsCalendar();
}

function nextIcsMonth() {
  icsMonth = new Date(icsMonth.getFullYear(), icsMonth.getMonth() + 1, 1);
  renderIcsCalendar();
}

async function fetchIcsText(url) {
  const candidates = [
    url,
    'https://api.allorigins.win/raw?url=' + encodeURIComponent(url),
    'https://corsproxy.io/?' + encodeURIComponent(url)
  ];

  let lastError = null;
  for (const candidate of candidates) {
    try {
      const res = await fetch(candidate, { cache: 'no-store' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const text = await res.text();
      if (text.includes('BEGIN:VCALENDAR') || text.includes('BEGIN:VEVENT')) return text;
    } catch (err) {
      lastError = err;
    }
  }
  throw lastError || new Error('Ne mogu učitati ICS.');
}

async function loadBookingCalendar() {
  const status = document.getElementById('calendarStatus');
  renderIcsCalendar();

  if (!BOOKING_ICS_URL) {
    if (status) status.textContent = 'Booking iCal link nije upisan.';
    return;
  }

  try {
    if (status) status.textContent = 'Učitavam zauzete termine iz Booking kalendara...';
    const text = await fetchIcsText(BOOKING_ICS_URL);
    busyRanges = parseBookingIcs(text);
    renderIcsCalendar();

    if (status) {
      status.textContent = busyRanges.length
        ? 'Kalendar je učitan. Crveni datumi su zauzeti termini.'
        : 'Kalendar je učitan, ali Booking trenutno nije poslao zauzete termine u iCal datoteci.';
    }
  } catch (err) {
    console.error(err);
    if (status) status.textContent = 'Kalendar se trenutno ne može automatski učitati zbog ograničenja Booking/CORS pristupa. Pošalji WhatsApp upit za provjeru termina.';
  }
}

document.addEventListener('DOMContentLoaded', loadBookingCalendar);
