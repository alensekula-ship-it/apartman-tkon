function moveGallery(direction){const slider=document.getElementById('gallerySlider');if(!slider)return;const amount=Math.min(360,slider.clientWidth*0.75);slider.scrollBy({left:direction*amount,behavior:'smooth'});}
let currentDate=new Date();
function renderCalendar(){const title=document.getElementById('calendarTitle');const days=document.getElementById('calendarDays');if(!title||!days)return;const year=currentDate.getFullYear();const month=currentDate.getMonth();const names=['Siječanj','Veljača','Ožujak','Travanj','Svibanj','Lipanj','Srpanj','Kolovoz','Rujan','Listopad','Studeni','Prosinac'];title.textContent=names[month]+' '+year;days.innerHTML='';const first=new Date(year,month,1);const last=new Date(year,month+1,0);let start=first.getDay();start=start===0?6:start-1;for(let i=0;i<start;i++){const e=document.createElement('span');e.className='muted';days.appendChild(e);}const today=new Date();for(let d=1;d<=last.getDate();d++){const cell=document.createElement('span');cell.textContent=d;if(d===today.getDate()&&month===today.getMonth()&&year===today.getFullYear()){cell.className='today';}days.appendChild(cell);}}
function changeMonth(delta){currentDate=new Date(currentDate.getFullYear(),currentDate.getMonth()+delta,1);renderCalendar();}
document.addEventListener('DOMContentLoaded',renderCalendar);


const ICS_SOURCE_URL = "https://ical.booking.com/v1/export?t=f417174c-656a-4f9d-b8eb-b26d0589cefd";
let calDate = new Date();
let occupiedDates = new Set();

function dateKey(date){
  const y = date.getFullYear();
  const m = String(date.getMonth()+1).padStart(2,'0');
  const d = String(date.getDate()).padStart(2,'0');
  return `${y}-${m}-${d}`;
}

function parseIcsDate(value){
  const s = String(value || '').trim().slice(0,8);
  const y = Number(s.slice(0,4));
  const m = Number(s.slice(4,6))-1;
  const d = Number(s.slice(6,8));
  if(!y || Number.isNaN(m) || !d) return null;
  return new Date(y,m,d);
}

function parseIcs(text){
  const clean = String(text || '').replace(/\r?\n[ \t]/g,'');
  const events = clean.split('BEGIN:VEVENT').slice(1);
  for(const ev of events){
    const ms = ev.match(/DTSTART(?:;[^:\r\n]*)?:(\d{8})/);
    const me = ev.match(/DTEND(?:;[^:\r\n]*)?:(\d{8})/);
    if(!ms || !me) continue;
    const start = parseIcsDate(ms[1]);
    const end = parseIcsDate(me[1]);
    if(!start || !end) continue;
    const cur = new Date(start.getFullYear(), start.getMonth(), start.getDate());
    while(cur < end){
      occupiedDates.add(dateKey(cur));
      cur.setDate(cur.getDate()+1);
    }
  }
}

function renderCalendar(){
  const t=document.getElementById('calTitle'), d=document.getElementById('days');
  if(!t||!d)return;
  const y=calDate.getFullYear(),m=calDate.getMonth();
  const names=['Siječanj','Veljača','Ožujak','Travanj','Svibanj','Lipanj','Srpanj','Kolovoz','Rujan','Listopad','Studeni','Prosinac'];
  t.textContent=names[m]+' '+y;
  d.innerHTML='';
  const first=new Date(y,m,1),last=new Date(y,m+1,0);
  let start=first.getDay();
  start=start===0?6:start-1;
  for(let i=0;i<start;i++){
    const s=document.createElement('span');
    s.className='empty';
    d.appendChild(s);
  }
  const today=new Date();
  for(let day=1;day<=last.getDate();day++){
    const date = new Date(y,m,day);
    const s=document.createElement('span');
    s.textContent=day;
    const cls=[];
    if(day===today.getDate()&&m===today.getMonth()&&y===today.getFullYear()) cls.push('today');
    if(occupiedDates.has(dateKey(date))) cls.push('busy');
    if(cls.length) s.className=cls.join(' ');
    d.appendChild(s);
  }
}

function changeMonth(delta){
  calDate=new Date(calDate.getFullYear(),calDate.getMonth()+delta,1);
  renderCalendar();
}

async function loadLocalBusyDates(){
  const res=await fetch('busy-dates.json?v='+Date.now(),{cache:'no-store'});
  if(!res.ok) throw new Error('Nema lokalne datoteke.');
  const data=await res.json();
  const dates=Array.isArray(data)?data:(data.busy||data.dates||[]);
  dates.forEach(x=>occupiedDates.add(String(x).slice(0,10)));
  return dates.length;
}

async function loadIcsViaProxy(){
  const urls=[
    'https://api.allorigins.win/raw?url='+encodeURIComponent(ICS_SOURCE_URL),
    'https://corsproxy.io/?'+encodeURIComponent(ICS_SOURCE_URL)
  ];
  let lastError=null;
  for(const url of urls){
    try{
      const res=await fetch(url,{cache:'no-store'});
      if(!res.ok) throw new Error('HTTP '+res.status);
      const text=await res.text();
      if(text.includes('BEGIN:VCALENDAR')||text.includes('BEGIN:VEVENT')){
        parseIcs(text);
        return occupiedDates.size;
      }
    }catch(e){lastError=e;}
  }
  throw lastError||new Error('Kalendar se ne može učitati.');
}

async function loadAvailability(){
  const status=document.getElementById('calendarStatus');
  renderCalendar();
  try{
    if(status) status.textContent='Učitavam kalendar...';
    try{
      await loadLocalBusyDates();
    }catch(e){
      await loadIcsViaProxy();
    }
    renderCalendar();
    if(status) status.textContent=occupiedDates.size?'Crveno označeni datumi su zauzeti.':'Kalendar je učitan. Trenutno nema označenih zauzetih datuma.';
  }catch(e){
    console.error(e);
    if(status) status.textContent='Kalendar se trenutno ne može automatski učitati. Pošalji WhatsApp upit za provjeru termina.';
  }
}

document.addEventListener('DOMContentLoaded',loadAvailability);
