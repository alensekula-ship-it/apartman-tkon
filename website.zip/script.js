function moveGallery(direction){const slider=document.getElementById('gallerySlider');if(!slider)return;const amount=Math.min(360,slider.clientWidth*0.75);slider.scrollBy({left:direction*amount,behavior:'smooth'});}
let currentDate = new Date();
let occupiedDates = new Set();

function pad2(n) {
  return String(n).padStart(2, '0');
}

function dateKey(date) {
  return date.getFullYear() + '-' + pad2(date.getMonth() + 1) + '-' + pad2(date.getDate());
}

function renderCalendar() {
  const title = document.getElementById('calendarTitle');
  const days = document.getElementById('calendarDays');
  if (!title || !days) return;

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const names = ['Siječanj','Veljača','Ožujak','Travanj','Svibanj','Lipanj','Srpanj','Kolovoz','Rujan','Listopad','Studeni','Prosinac'];

  title.textContent = names[month] + ' ' + year;
  days.innerHTML = '';

  const first = new Date(year, month, 1);
  const last = new Date(year, month + 1, 0);
  let start = first.getDay();
  start = start === 0 ? 6 : start - 1;

  for (let i = 0; i < start; i++) {
    const e = document.createElement('span');
    e.className = 'muted';
    days.appendChild(e);
  }

  const today = new Date();
  for (let d = 1; d <= last.getDate(); d++) {
    const date = new Date(year, month, d);
    const cell = document.createElement('span');
    cell.textContent = d;

    const classes = [];
    if (d === today.getDate() && month === today.getMonth() && year === today.getFullYear()) classes.push('today');
    if (occupiedDates.has(dateKey(date))) classes.push('busy');
    if (classes.length) cell.className = classes.join(' ');

    days.appendChild(cell);
  }
}

function changeMonth(delta) {
  currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + delta, 1);
  renderCalendar();
}

async function loadAvailabilityCalendar() {
  const status = document.getElementById('calendarStatus');
  renderCalendar();

  try {
    if (status) status.textContent = 'Učitavam kalendar...';

    const res = await fetch('busy-dates.json?v=' + Date.now(), { cache: 'no-store' });
    if (!res.ok) throw new Error('Nema datoteke s datumima.');

    const data = await res.json();
    const dates = Array.isArray(data) ? data : (data.busy || []);
    occupiedDates = new Set(dates.map(x => String(x).slice(0, 10)));

    renderCalendar();

    if (status) {
      status.textContent = occupiedDates.size
        ? 'Crveno označeni datumi su zauzeti.'
        : 'Kalendar je učitan. Trenutno nema označenih zauzetih datuma.';
    }
  } catch (e) {
    console.error(e);
    renderCalendar();
    if (status) status.textContent = 'Kalendar se trenutno ne može učitati. Pošalji WhatsApp upit za provjeru termina.';
  }
}

document.addEventListener('DOMContentLoaded', loadAvailabilityCalendar);
