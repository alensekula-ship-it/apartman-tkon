function moveGallery(direction){const slider=document.getElementById('gallerySlider');if(!slider)return;const amount=Math.min(360,slider.clientWidth*0.75);slider.scrollBy({left:direction*amount,behavior:'smooth'});}
let currentDate = new Date();
let occupiedDates = new Set();

function pad2(n) {
  return String(n).padStart(2, '0');
}

function dateKey(date) {
  return date.getFullYear() + '-' + pad2(date.getMonth() + 1) + '-' + pad2(date.getDate());
}

function renderCalendar() {
  const title = document.getElementById('calendarTitle');
  const days = document.getElementById('calendarDays');
  if (!title || !days) return;

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const names = ['Siječanj','Veljača','Ožujak','Travanj','Svibanj','Lipanj','Srpanj','Kolovoz','Rujan','Listopad','Studeni','Prosinac'];

  title.textContent = names[month] + ' ' + year;
  days.innerHTML = '';

  const first = new Date(year, month, 1);
  const last = new Date(year, month + 1, 0);
  let start = first.getDay();
  start = start === 0 ? 6 : start - 1;

  for (let i = 0; i < start; i++) {
    const e = document.createElement('span');
    e.className = 'muted';
    days.appendChild(e);
  }

  const today = new Date();
  for (let d = 1; d <= last.getDate(); d++) {
    const date = new Date(year, month, d);
    const cell = document.createElement('span');
    cell.textContent = d;

    const classes = [];
    if (d === today.getDate() && month === today.getMonth() && year === today.getFullYear()) classes.push('today');
    if (occupiedDates.has(dateKey(date))) classes.push('busy');
    if (classes.length) cell.className = classes.join(' ');

    days.appendChild(cell);
  }
}

function changeMonth(delta) {
  currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + delta, 1);
  renderCalendar();
}

async function loadAvailabilityCalendar() {
  const status = document.getElementById('calendarStatus');
  renderCalendar();

  try {
    if (status) status.textContent = 'Učitavam kalendar...';

    const res = await fetch('busy-dates.json?v=' + Date.now(), { cache: 'no-store' });
    if (!res.ok) throw new Error('Nema datoteke s datumima.');

    const data = await res.json();
    const dates = Array.isArray(data) ? data : (data.busy || []);
    occupiedDates = new Set(dates.map(x => String(x).slice(0, 10)));

    renderCalendar();

    if (status) {
      status.textContent = occupiedDates.size
        ? 'Crveno označeni datumi su zauzeti.'
        : 'Kalendar je učitan. Trenutno nema označenih zauzetih datuma.';
    }
  } catch (e) {
    console.error(e);
    renderCalendar();
    if (status) status.textContent = 'Kalendar se trenutno ne može učitati. Pošalji WhatsApp upit za provjeru termina.';
  }
}

document.addEventListener('DOMContentLoaded', loadAvailabilityCalendar);


/* GALERIJA LIGHTBOX - strelice i swipe */
const galleryImages = [
  { src: 'photo_01.jpg', alt: 'Terasa s pogledom na more' },
  { src: 'photo_02.jpg', alt: 'Blagovaonica' },
  { src: 'photo_03.jpg', alt: 'Kuhinja' },
  { src: 'photo_04.jpg', alt: 'Spavaća soba' },
  { src: 'photo_05.jpg', alt: 'Dvokrevetna soba' },
  { src: 'photo_06.jpg', alt: 'Soba s krevetima' },
  { src: 'photo_07.jpg', alt: 'WC' },
  { src: 'photo_08.jpg', alt: 'Tuš' }
];

let currentLightboxIndex = 0;
let savedScrollY = 0;
let lightboxTouchStartX = 0;
let lightboxTouchStartY = 0;

function openLightbox(index) {
  const lightbox = document.getElementById('galleryLightbox');
  const image = document.getElementById('lightboxImage');
  if (!lightbox || !image) return;

  savedScrollY = window.scrollY || document.documentElement.scrollTop || 0;
  currentLightboxIndex = (index + galleryImages.length) % galleryImages.length;

  image.src = galleryImages[currentLightboxIndex].src;
  image.alt = galleryImages[currentLightboxIndex].alt;

  lightbox.classList.add('is-open');
  lightbox.setAttribute('aria-hidden', 'false');
  document.body.classList.add('lightbox-open');
}

function closeLightbox() {
  const lightbox = document.getElementById('galleryLightbox');
  if (!lightbox) return;

  lightbox.classList.remove('is-open');
  lightbox.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('lightbox-open');

  requestAnimationFrame(() => window.scrollTo(0, savedScrollY));
}

function changeLightbox(direction) {
  currentLightboxIndex = (currentLightboxIndex + direction + galleryImages.length) % galleryImages.length;
  const image = document.getElementById('lightboxImage');
  if (!image) return;

  image.src = galleryImages[currentLightboxIndex].src;
  image.alt = galleryImages[currentLightboxIndex].alt;
}

document.addEventListener('keydown', function(e) {
  const lightbox = document.getElementById('galleryLightbox');
  if (!lightbox || !lightbox.classList.contains('is-open')) return;

  if (e.key === 'Escape') closeLightbox();
  if (e.key === 'ArrowLeft') changeLightbox(-1);
  if (e.key === 'ArrowRight') changeLightbox(1);
});

document.addEventListener('click', function(e) {
  const lightbox = document.getElementById('galleryLightbox');
  if (!lightbox || !lightbox.classList.contains('is-open')) return;
  if (e.target === lightbox) closeLightbox();
});

document.addEventListener('touchstart', function(e) {
  const lightbox = document.getElementById('galleryLightbox');
  if (!lightbox || !lightbox.classList.contains('is-open')) return;
  if (!e.touches || !e.touches.length) return;

  lightboxTouchStartX = e.touches[0].clientX;
  lightboxTouchStartY = e.touches[0].clientY;
}, { passive: true });

document.addEventListener('touchend', function(e) {
  const lightbox = document.getElementById('galleryLightbox');
  if (!lightbox || !lightbox.classList.contains('is-open')) return;
  if (!e.changedTouches || !e.changedTouches.length) return;

  const diffX = e.changedTouches[0].clientX - lightboxTouchStartX;
  const diffY = e.changedTouches[0].clientY - lightboxTouchStartY;

  if (Math.abs(diffX) > 45 && Math.abs(diffX) > Math.abs(diffY)) {
    changeLightbox(diffX < 0 ? 1 : -1);
  }
}, { passive: true });

